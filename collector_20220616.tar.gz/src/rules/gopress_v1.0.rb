#encoding: UTF-8
require 'data_collector'
require "iso639"

RULE_SET_v1_0 = {
    version: "1.0",
    rs_records: {
        records: { "$" => lambda { |d,o|
                out = DataCollector::Output.new
                rules_ng.run(RULE_SET_v1_0[:rs_data], d["article.published"], out, o)
                data = out[:data]
                data
        } }
    },
    rs_data: {
        data: { "@" => lambda {|d,o|
            date_published =  DateTime.parse( d["head"]["id"]["_pubdate"] ).strftime("%Y-%m-%d")
            issue_id       =  d["head"]["id"]["_issue"]

# puts "issue_id #{issue_id}"
# if "13567380" == issue_id
#    pp d
# end
            rdata = {
                :datePublished => date_published,
                :publisher     => {
                    :@type => "Organization",
                    :@id   => I18n.transliterate( d["head"]["id"]["_title"] ).delete(' ').delete('\''),
                    :name  => d["head"]["meta"]["publication"]["$text"]
                },
            }

            INGEST_CONF[:dataset] = {
                    "@id": d["head"]["id"]["_title"],
                    "@type": "Dataset",
                    "name": rdata[:publisher][:name]
            }
            INGEST_CONF[:genericRecordDesc] = "Entry from GoPress - #{  rdata[:publisher][:name]  }"


            out = DataCollector::Output.new
            rules_ng.run(RULE_SET_v1_0[:rs_basic_schema], d, out, o)
            rdata.merge!(out[:basic_schema].to_h)
            o[:@id] = out[:basic_schema].to_h[:@id] 
            out.clear

            rules_ng.run(RULE_SET_v1_0[:rs_in_language], d, out, o)
            rules_ng.run(RULE_SET_v1_0[:rs_dateline], d, out, o)
            rules_ng.run(RULE_SET_v1_0[:rs_authortagline], d, out, o)
            rules_ng.run(RULE_SET_v1_0[:rs_attachments], d, out, o)

            rdata.merge!(out.to_h)
            out.clear

            rules_ng.run(RULE_SET_v1_0[:rs_body_head], d, out, o)
            rdata.merge!(out[:body_head].to_h)
                   
            rules_ng.run(RULE_SET_v1_0[:rs_meta], d, out, o)
            rdata.merge!(out[:meta].to_h)

            rules_ng.run(RULE_SET_v1_0[:rs_body_coords], d, out, o)
            if out[:body_coords].kind_of?(Array)
                coord = {
                    :page_start => out[:body_coords].map{ |c| c[:page_start]}.min,
                    :page_end   => out[:body_coords].map{ |c| c[:page_end]}.max
                }
                coord[:pagination] = "#{ coord[:page_start] }-#{ coord[:page_end] }"
                rdata.merge!(coord)
            else
                rdata.merge!(out[:body_coords].to_h)
            end

            rules_ng.run(RULE_SET_v1_0[:rs_body_content], d, out, o)
            rdata.merge!(out[:body_content].to_h)
            out.clear

            if rdata[:headline].nil?
                rdata[:headline] = rdata[:articleBody].first.to_s.truncate( 150, separator: ' ')
            else
                rdata[:headline] = rdata[:headline][0]
            end
            rdata[:name] = rdata[:headline]
            rdata[:articleBody] = rdata[:articleBody].first unless rdata[:articleBody].size != 1

            rdata[:sameAs] = "http://academic.gopress.be/Public/index.php?page=archive-article&issueDate=#{date_published}&articleOriginalId=#{issue_id}"
            
            rules_ng.run(RULE_SET_v1_0[:rs_attachments], d, out, o)

            out.clear

            #            pp rdata
            rdata.compact
        }
      }
    },
    rs_body_head:{
        body_head: { "$.body.['body.head']" => lambda { |d,o|  
            rdata = {
                :name => ""  
            }
            out = DataCollector::Output.new
            rules_ng.run(RULE_SET_v1_0[:rs_headline], d, out, o)
            rules_ng.run(RULE_SET_v1_0[:rs_attachments], d, out, o)
            rdata.merge!(out.to_h)
            rdata
        } }
    },
    rs_meta: {
        _meta: { "$.meta" => lambda { |d,o|  
            rdata ={}
            rdata[:articleSection] = d["section"].join(", ")
            rdata[:printEdition]   = d["edition"]["$text"].join(", ") unless d["edition"].nil?

            o[:index] = 0
            rules_ng.run(RULE_SET_v1_0[:rs_content_location], d, out, o)
            rdata.merge!(out.to_h)
            rdata
        } }
    },
    rs_body_coords: {
        body_coords: { "$.body.coords" => lambda { |d,o|  
            rdata = {
                :page_start => d["_pageId"],
                :page_end   => d["_pageId"]
            }

            unless rdata[:page_start].nil?  || rdata[:page_end].nil?
                rdata[:pagination] = "#{ rdata[:page_start]}-#{ rdata[:page_end] }"
            end
            rdata
        } }
    },
    rs_body_content:{
        body_content: { "$.body.['body.content']" => lambda { |d,o|  
            out = DataCollector::Output.new
            rules_ng.run(RULE_SET_v1_0[:rs_article_body], d, out, o)
            rules_ng.run(RULE_SET_v1_0[:rs_lead], d, out, o)
            out.to_h
        } }
    },
    rs_lead: {
        description: { "$.lead.['body.p']" => lambda { |d,o|  
            out = DataCollector::Output.new
            rules_ng.run(RULE_SET_v1_0[:rs_p], d, out, o)
            Nokogiri::HTML(   out[:p].join(" ") ).text
        } }
    },
    rs_article_body:{
        articleBody: { "$.['body.p']" => lambda { |d,o|
            if d["p"].nil?
                "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp is nil"
            else
                out = DataCollector::Output.new
                rules_ng.run(RULE_SET_v1_0[:rs_p], d, out, o)
                Nokogiri::HTML(   out[:p].join(" ") ).text
            end

        } }
    },
    rs_p:{
        p: { "$.p" => lambda { |d,o|
                 d
        } }
    },
    rs_basic_schema: {
        basic_schema: { "@" => lambda { |d,o|  
            
            title_id       = d["head"]["id"]["_title"]
            scope_id       = d["head"]["id"]["_scope"]
            issue_id       = d["head"]["id"]["_issue"]
            date_published =  DateTime.parse( d["head"]["id"]["_pubdate"] ).strftime("%d%m%Y")
            
            id = "#{title_id}#{scope_id}#{issue_id}#{date_published}-00000"

            unless Iso639[d["_xml:lang"]].nil? || Iso639[d["_xml:lang"]].alpha2.to_s.empty?
                language = Iso639[d["_xml:lang"]].alpha2
            else
                language = INGEST_CONF[:metaLanguage]
            end

            {
                :@id            => "#{ INGEST_CONF[:prefixid] }_#{  INGEST_CONF[:provider][:@id].downcase }_#{ INGEST_CONF[:dataset][:@id].downcase }_#{id}",
                :@type          => o[:type],
                :additionalType => "CreativeWork",
                :isBasedOn      => {
                    :@type    => "CreativeWork",
                    :@id      => "#{ INGEST_CONF[:prefixid] }_#{  INGEST_CONF[:provider][:@id].downcase }_#{ INGEST_CONF[:dataset][:@id].downcase }",
                    :license  => INGEST_CONF[:license],
                    :name     => INGEST_CONF[:genericRecordDesc],
                    :provider => INGEST_CONF[:provider],
                    :isPartOf => {
                        :@id   => INGEST_CONF[:dataset][:@id].downcase,
                        :@type => "Dataset",
                        :name  => INGEST_CONF[:dataset][:name]
                    }
                },
                :@context  => ["http://schema.org", { :@language => "#{ language }-#{ INGEST_CONF[:unicode_script]}" }]    
            }
        }}
    },
    rs_headline: {
        headline:  { "$" => lambda { |d,o| 
            headline = headline2 = byline = nil
            unless d["headline"].nil?
                headline  = d["headline"]["hl1"]["p"] unless d["headline"]["hl1"].nil?
                headline2 = d["headline"]["hl2"]["p"] unless d["headline"]["hl2"].nil?
            end
            unless d["byline"].nil?
                if d["byline"]["p"].kind_of?(Array)
                   byline  = d["byline"]["p"].join(', ') 
                else
                    byline = d["byline"]["p"]
                end
                byline = Nokogiri::HTML( byline ).text.truncate( 150, separator: ' ') 
            end
            headline = Nokogiri::HTML( [ headline, headline2 ].reject { |item| item.nil? }.join(', ') ).text 
            headline = [ headline, byline].reject { |item| item.nil? || item.empty? }
            headline = headline.first unless headline.nil?
            headline

        }}
    },
    rs_in_language: {
        inLanguage: { "$._xml:lang" =>  lambda { |d,o| 
            unless Iso639[ d ].nil? || Iso639[ d ] .alpha2.to_s.empty?
                data = {
                    :@type         => "Language",
                    :@id           => Iso639[d].alpha2,
                    :name          => Iso639[d].name,
                    :alternateName => Iso639[d].alpha2,
                }
            end
            data
        }}
    },
    rs_dateline: {
        dateline: { "@" =>  [ lambda { |d,o| 
            [ d["head"]["meta"]["location"] , DateTime.parse(  d["head"]["id"]["_pubdate"] ).strftime("%Y-%m-%d")  ].flatten.reject { |item| item.nil? || item.empty? }.join(', ')

        }] }
    },
    rs_content_location: {
        contentLocation: { "$" =>  lambda { |d,o| 
            rdata = d["location"]
            rdata =  rdata.values.each_with_index.map do |l, i|  
                {
                    :@type => "Place",
                    # id will be added with write_schema_out => add_all_ids
                    # otherwise duplicate ids could be generated
                    :@id => "#{o[:@id]}_PLACE_#{i}", 
                    :name => l,
                }
            end
            rdata
        } }
    },
    rs_authortagline: {
        creator: { "$.body.['body.end'].tagline.authortagline.p" =>  lambda { |d,o| 
            {
                :@type => "Person",
                :@id => "#{o[:@id]}_PERSON_0",
                :name => d
            }
    }}
    },
    rs_attachments: {
        associatedMedia: { "$.body.['body.head'].attachments.images" =>  lambda { |d,o| 
            rdata = d["_file"]
            rdata =  rdata.values.each_with_index.map do |l, i|  
                {
                    :@type => "ImageObject",
                    :author     => l["credit"],
                    :caption    => l["caption"],
                    :contentUrl => l["_file"],
                    :@id => "#{o[:@id]}_PLACE_#{i}"
                }
            end
            rdata
    }}
    }
    
}
