#encoding: UTF-8
$LOAD_PATH << '.' << './lib' << "#{File.dirname(__FILE__)}" << "#{File.dirname(__FILE__)}/lib"
require "unicode"
require 'logger'
require 'icandid'
require_relative './rules/gopress_backlog_v1.0'
# require 'belgapress_utils'

################################################################################################
# Om de backlog records te parsen, moet de parameter -s in de commandline worden gebruikt
#  => ruby ./src/gopress_parser.rb -s /source_records/GoPress/backlog/ -u "2010-01-01T01:00:00Z" -p "*.xml.gz"
#
# 
# Om de "backlog" van recente records te parsn, gebruik commandline parameters
#  => ruby ./src/gopress_parser.rb -s /source_records/GoPress/**/*.202202*.zip -u "2010-01-01T01:00:00Z"
#

include Icandid

@logger = Logger.new(STDOUT)
@logger.level = Logger::DEBUG

ADMIN_MAIL_ADDRESS = "tom.vanmechelen@kuleuven.be"
ROOT_PATH = File.join( File.dirname(__FILE__), '../')

# ConfJson = File.read( File.join(ROOT_PATH, './config/config.cfg') )
# ICANDID_CONF = JSON.parse(ConfJson, :symbolize_names => true)
PROCESS_TYPE  = "parser"  # used to determine (command line) config options
SOURCE_DIR   = '/source_records/GoPress/'
SOURCE_FILE_NAME_PATTERN = "*.zip"

RECORDS_DIR  = '/records/GoPress/'

ConfJson = File.read(File.join(ROOT_PATH, './config/config.cfg'))
ICANDID_CONF = JSON.parse(ConfJson, :symbolize_names => true)

ingestConfJson =  File.read(File.join(ROOT_PATH, './config/GoPress/ingest.cfg'))
INGEST_CONF = JSON.parse(ingestConfJson, :symbolize_names => true)

INGEST_CONF[:prefixid] = ICANDID_CONF[:prefixid]
INGEST_CONF[:genericRecordDesc] = "Entry from #{INGEST_CONF[:dataset][:name]}"

#############################################################
TESTING = true
STATUS = "parsing"

begin
  config = {
    :config_path => File.join(ROOT_PATH, './config/GoPress/'),
    :config_file => "config.yml",
    :query_config_path => File.join(ROOT_PATH, './config/GoPress/'),
    :query_config_file => "queries.yml"
  }

  icandid_config = Icandid::Config.new( config: config )
  
  collector = IcandidCollector::Input.new( icandid_config.config )

  @logger.info ("Start parsing using config: #{ icandid_config.config.path}/#{ icandid_config.config.file} ")

  start_process  = Time.now.strftime("%Y-%m-%dT%H:%M:%SZ")
  
  @logger.info ("Parsing for queries in : #{ icandid_config.query_config.path }#{ icandid_config.query_config.file }")

  options = {
    :type => "NewsArticle",
    :prefixid => "#{INGEST_CONF[:prefixid]}_#{ INGEST_CONF[:provider][:@id].downcase }_#{ INGEST_CONF[:dataset][:@id].downcase }",
    :papers_to_process => ["demorgen","destandaard","detijd","gazetvanantwerpen","hetbelangvanlimburg","hetlaatstenieuws","hetnieuwsblad","metro","metronl","metrofr"]
  }

  rule_set =  BACKLOG_RULE_SET_v1_0
  "extract_destination = "#{ f[:source_records_dir] }xml_extract/"
  extract_destination = "/xml_extract/"

  @logger.info("Deleting extract_destination #{extract_destination}*")
  Dir.glob("#{extract_destination}/*").each { |file| File.delete(file) }

  source_records_dir = icandid_config.get_source_records_dir( options: {})
#  last_parsing_datetime = icandid_config.get_parsing_datetime( query: query )
  source_file_name_pattern = icandid_config.get_file_name_pattern()

  
  @logger.info ("Start parsing source_records_dir: #{source_records_dir} ")
  @logger.info ("Start parsing source_file_name_pattern: #{source_file_name_pattern}")

  Dir.glob("#{ source_records_dir }#{ source_file_name_pattern }").each do |z_file|

    @logger.debug("#{ z_file } ctime(z_file) #{ File.ctime(z_file) } ")
    @logger.debug("#{ z_file } mtime(z_file) #{ File.mtime(z_file) } ")
    @logger.debug("extract  #{ z_file } ")

    if  File.extname( z_file )  == ".gz"
      f_path = File.join(extract_destination, File.basename(z_file, '.gz'))
      Zlib::GzipReader.open(z_file) do | input_stream |
        File.open(f_path, "w") do |output_stream|
          IO.copy_stream(input_stream, output_stream)
        end
      end
    end


    Dir["#{extract_destination}/*.xml"].each.with_index do |source_file, index| 

      doc = input.from_uri("file://#{ source_file }", {} )

      icandid_config.query_config[:queries].each.with_index() do |query, index|
        @logger.info ("Paring records for query: #{ query[:query][:id] } [ #{ query[:query][:name] } ]")

        INGEST_CONF[:dataset][:@id]  = query[:query][:id]
        INGEST_CONF[:dataset][:name] = query[:query][:name].gsub(/_/," ").capitalize()

        dir_options = { 
          :query =>  query[:query], 
          :date => Date.today.strftime("%Y/%m/%d")
        }

        doc["news"]["text"].select { |d|  
          if d["product"].nil?
            puts d["product"]
            puts d
          end
          ! d["product"].nil? && ( query[:query][:value].downcase == d["product"].gsub(/[[:space:]]/, '').downcase )
        }.each_slice(100).with_index do |d, i|
          d = {
            "news" => {
              "text" => d
            }
          }
          files_to_parse = "#{source_file}-#{ query[:query][:value].downcase }.json"
          File.open(files_to_parse, 'w') {|f| f.write( d.to_json ) }

          collector.parse_data( file: files_to_parse, options: options, rule_set: rule_set )
          collector.write_records( records_dir:  icandid_config.get_records_dir( options:dir_options) )

        end
      end
    end

    @logger.info("Deleting extract_destination #{extract_destination}*")
    Dir.glob("#{extract_destination}/*").each { |file| File.delete(file) }

  end

  icandid_config.update_system_status("ready")

rescue StandardError => e
  @logger.error("#{ e.message  }")
  @logger.error("#{ e.backtrace.inspect   }")

  importance = "High"
  subject = "[ERROR] iCANDID ENA parsing"
  message = <<END_OF_MESSAGE
  
  <h2>Error while parsing ENA data</h2>
  <p>#{e.message}</p>
  <p>#{e.backtrace.inspect}</p>
  
  <hr>
  
END_OF_MESSAGE

  mailErrorReport(subject, message, importance, config)

  @logger.info("ENA Parsing is finished with errors")

end
