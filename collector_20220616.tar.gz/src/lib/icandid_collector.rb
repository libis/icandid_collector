#encoding: UTF-8
require 'yaml'
require 'logger'
require 'zip'
require 'data_collector'

include DataCollector::Core

module IcandidCollector
  class Input 

    attr_accessor :config, :retries

    def initialize(config, url_options = {})
      @logger = Logger.new(STDOUT)
      @config = config
      @retries = 0
    end

    def login(url_options)

      @logger.info ("Get new tokens trough credentials")
      
      auth = @config[:auth]

      uri = auth[:login_url]

      uri.scan(/\{\{([^{}]*)\}\}/).each { |substitution|
        substitution = substitution[0]
        if  auth[substitution.to_sym].nil?
          raise ("Missing option \"#{ substitution }\" to substitute uri")
        else
          uri = uri.gsub(/\{\{#{substitution}\}\}/,auth[substitution.to_sym])
        end
      }

      uri = URI(uri)

      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl = true
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE
      request = Net::HTTP::Post.new(uri)

      if login_request_body = auth[:login_request_body]
        login_request_body.scan(/\{\{([^{}]*)\}\}/).each { |substitution|
          substitution = substitution[0]
          if  auth[substitution.to_sym].nil?
            raise ("Missing option \"#{ substitution }\" to substitute login_request_body")
          else
            login_request_body = login_request_body.gsub(/\{\{#{substitution}\}\}/, auth[substitution.to_sym])
          end
        }
        request.body = login_request_body
      end
      http_response = http.request(request)            

      if http_response.code === '401'
          raise "Unable to login received status code = #{http_response.code}"
          return false
      end
      
      auth[:access_token] = JSON.parse( http_response.body.to_s )["access_token"]
      auth[:bearer_token] = JSON.parse( http_response.body.to_s )["access_token"]
      auth[:refresh_token] =JSON.parse( http_response.body.to_s )["refresh_token"]
      @config[:auth] = auth

      return true
    end


    def get_data(url, url_options)
      begin
        number_of_retries = url_options[:number_of_retries] || 2
        @retry_count = 0 if @retry_count.nil?
        timing_start = Time.now
       
        @url_options = url_options

        data = input.from_uri(url, url_options)

        unless data["error"].nil?
          @logger.error("Data response: [#{ data["error"]["code"]}] #{ data["error"]["message"]}")  
          case data["error"]["code"].to_i
          when 400
            data = JSON.parse( input.raw )
          when 401
              @logger.info ("Authentication failed:")
              if login(url_options)
                  @logger.info ("Config file updated with new tokens")
                  @logger.info ("Recall the get_request")
                  url_options[:bearer_token] =  @config[:auth][:bearer_token]
                  data = get_data(url, url_options)
              end
          when 429 
            if @retry_count < number_of_retries
              @retry_count += 1
              @logger.error ("Wait 300 seconds and try Again ==> number_of_retries:#{@retry_count}")
              sleep 300
              #data = get_data(url, url_options)
              #@raw = input.raw
              data = get_data(url, url_options)
              @retry_count -= 1
            else
              @logger.error("429 and to many redirects")
              @logger.error( input.raw )
              raise "429 and to many redirects"
            end
          when 503 
            if @retry_count < number_of_retries
              @retry_count += 1
              @logger.error ("Wait 15 seconds and try Again ==> number_of_retries:#{@retry_count}")
              sleep 15
              #data = get_data(url, url_options)
              #@raw = input.raw
              data = get_data(url, url_options)
            end                
          else
            @logger.error( input.raw )
            raise "API request failed"
          end
        end
        data
      rescue => exception
        @logger.error("Error : #{ exception } ")
        raise "Error get_data !!!! ==> number_of_retries:#{@retry_count}"
      end
    end

    def parse_data( file: "", options: {}, rule_set: nil )
      begin
        if rule_set.nil?
          raise "rule_set is required to parse file"
        end
        output.clear()
        data = input.from_uri("file://#{ file }", {} )
                
        @logger.debug(" options #{ options }")

        # @logger.debug(" rules_ng.run #{ rule_set }")
        # pp data
        #puts rule_set[:version]
        #puts "================>"

        rules_ng.run( rule_set[:rs_records], data, output, options )

        #pp output.raw
        
        output.crush

      rescue StandardError => e
        @logger.error("Error parsing file  #{file} ")  
        @logger.error("#{ e.message  }")
        @logger.error("#{ e.backtrace.inspect   }")
        @logger.error( "HELP, HELP !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        raise e
        exit
      end
    end

    def csv_file_to_hash(file, seprator=",", encoding="UTF-8")
      begin
          @raw = rdata = File.read("#{file}", :encoding => encoding).scrub
  
          #@logger.debug("csv_file_to_hash #{encoding} #{file}") 
          orig_encoding = rdata.encoding
          rdata.force_encoding("UTF-8")
          unless rdata.valid_encoding?
            raise (" file encoding has invalid UTF-8")
          end
  
  #        rdata = rdata.gsub('\"', "'")
          data = CSV.parse(rdata, headers: true, col_sep: seprator)
  
          data
      rescue StandardError => msg
          puts "Error csv_file_to_hash: unable to read CSV #{file}"
          puts "msg: #{msg}"
          {}
      end
    end

    def unzip_file (file, destination)
      @logger.info("Unzip #{file}") 
      Zip::ZipFile.open(file) do |zip_file|
        
        @logger.info("Unzip zip_file #{zip_file}") 
  
          zip_file.each do |f|
              f_path = File.join(destination, f.name)
              FileUtils.mkdir_p(File.dirname(f_path))
              f.extract(f_path) unless File.exist?(f_path)
          end
      end
    end


    def write_records(records_dir: nil )
      if records_dir.nil?
        raise "no records_dir specified !"
      end

      @logger.debug(" Output to folder:  #{records_dir}")        

      unless output[:records].nil?
          if output[:records].is_a?(Array)
              output[:records].each do |record|
                  write_file(record: record, record_file_name: record[:@id], records_dir: records_dir)
              end
          else
              record = output[:records]
              write_file(record: record, record_file_name: record[:@id], records_dir: records_dir)
          end
      end
    end

    def write_file(record: ,  record_file_name: nil, records_dir:)
      if record.nil?
        raise "record specified !"
      end
      if records_dir.nil?
        raise "no records_dir specified !"
      end

      if @config[:dir_based_on_datePublished]
        if record[:datePublished].nil?
            raise "record[:datePublished] may not be nil if @dir_based_on_datePublished  is true"
        end
        records_dir = records_dir.gsub(/\{\{record_dataPublished\}\}/, record[:datePublished].to_datetime.year.to_s)
      end

      output.to_jsonfile( record, record_file_name, records_dir, @config[:override_parsed_records])
      output.clear()
    end

  end
end
